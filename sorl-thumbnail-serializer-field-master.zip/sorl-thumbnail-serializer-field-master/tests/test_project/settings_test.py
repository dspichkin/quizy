from settings import *  # NOQA

ROOT_URLCONF = 'tests.test_project.urls'
